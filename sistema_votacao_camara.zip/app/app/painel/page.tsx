
import { PublicDisplayPanel } from "@/components/public-display-panel"

export default function PainelPublico() {
  return <PublicDisplayPanel />
}
